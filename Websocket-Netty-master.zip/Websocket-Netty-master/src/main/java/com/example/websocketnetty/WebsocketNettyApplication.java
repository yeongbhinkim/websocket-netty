package com.example.websocketnetty;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebsocketNettyApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebsocketNettyApplication.class, args);
	}

}
