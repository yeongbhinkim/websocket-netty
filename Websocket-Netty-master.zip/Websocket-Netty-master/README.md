# Introduction

This project is for learning the basics of Netty(Server And Client) using WebSocket And SpringBoot

# How to use

    http://localhost:8080/master
    http://localhost:8080/guest
    
![Animation](https://user-images.githubusercontent.com/47946124/206891502-72e44282-ed1a-44b4-97aa-ac3ace3eaa9e.gif)
